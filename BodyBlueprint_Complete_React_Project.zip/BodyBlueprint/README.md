# BodyBlueprint – HealthHub Hack

A responsive React wellness dashboard for recording hydration and sleep, viewing educational body-metric estimates, and receiving general habit suggestions.

## Features

- BMI calculator with metric inputs and a clear note that BMI is a screening measure, not a diagnosis.
- Adult-only Mifflin–St Jeor BMR estimate; the app does not show an adult BMR estimate for people under 18.
- Quick water logging (+250 ml and +500 ml), daily progress, and reset.
- Bedtime, wake-up time, sleep duration, and restfulness rating.
- Daily wellness indicator based on hydration progress, sleep duration, and sleep restfulness. It does **not** score body size.
- Seven-day sample/history chart.
- LocalStorage persistence.
- Responsive layout and dark/light theme toggle.

## Requirements

- Node.js 18 or newer
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Create a production build

```bash
npm run build
npm run preview
```

The production files are generated in `dist/`.

## GitHub upload

Upload the contents of this project folder to your public GitHub repository. Include `README.md`, `package.json`, `index.html`, and `src/`. Do not upload `node_modules/` or `dist/`.

To create a ZIP for submission, zip the project folder while excluding `node_modules/` and `dist/`.

## Health and privacy notes

This is an educational demo, not a medical device or diagnostic service. BMI is a limited screening measure. For users under 18, adult BMI categories should not be used; age- and sex-specific growth references require appropriate clinical context. The Mifflin–St Jeor BMR equation is an adult estimate, so this app does not calculate it for users under 18. Wellness points summarize logged habits only and are not a measure of a person's worth or overall health. Data is stored locally in the browser on the device being used.
