import React, { useEffect, useMemo, useState } from "react";
import {
  Activity, Droplets, Moon, HeartPulse, LayoutDashboard, History,
  Lightbulb, Settings, Plus, RotateCcw, Sun, MoonStar, CheckCircle2,
  Info, ArrowUpRight, Clock3, CalendarDays, Sparkles
} from "lucide-react";

const todayKey = () => new Date().toISOString().slice(0, 10);
const defaultState = {
  profile: { age: "", height: "", weight: "", sex: "female" },
  water: 0,
  sleep: { bedtime: "22:30", wakeTime: "06:30", restfulness: 4 },
  logs: {}
};

function readSaved() {
  try {
    const parsed = JSON.parse(localStorage.getItem("bodyblueprint-data"));
    return parsed ? { ...defaultState, ...parsed } : defaultState;
  } catch { return defaultState; }
}

function sleepHours(bedtime, wakeTime) {
  if (!bedtime || !wakeTime) return 0;
  const [bh, bm] = bedtime.split(":").map(Number);
  const [wh, wm] = wakeTime.split(":").map(Number);
  let start = bh * 60 + bm;
  let end = wh * 60 + wm;
  if (end <= start) end += 24 * 60;
  return Math.round(((end - start) / 60) * 10) / 10;
}

function bmiValue(weight, heightCm) {
  const h = Number(heightCm) / 100;
  if (!Number(weight) || !h || h <= 0) return null;
  return Number(weight) / (h * h);
}

function bmrValue({ age, height, weight, sex }) {
  const a = Number(age), h = Number(height), w = Number(weight);
  if (a < 18 || !a || !h || !w) return null;
  return sex === "male"
    ? 10 * w + 6.25 * h - 5 * a + 5
    : 10 * w + 6.25 * h - 5 * a - 161;
}

function App() {
  const [data, setData] = useState(readSaved);
  const [page, setPage] = useState("dashboard");
  const [dark, setDark] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    localStorage.setItem("bodyblueprint-data", JSON.stringify(data));
  }, [data]);

  useEffect(() => {
    const timer = setTimeout(() => setNotice(""), 2600);
    return () => clearTimeout(timer);
  }, [notice]);

  const bmi = useMemo(() => bmiValue(data.profile.weight, data.profile.height), [data.profile]);
  const bmr = useMemo(() => bmrValue(data.profile), [data.profile]);
  const hours = useMemo(() => sleepHours(data.sleep.bedtime, data.sleep.wakeTime), [data.sleep]);
  const hydrationGoal = 2000;
  const waterScore = Math.min(100, (data.water / hydrationGoal) * 100);
  const sleepScore = Math.min(100, (hours / 8) * 100);
  const restScore = (Number(data.sleep.restfulness) / 5) * 100;
  const wellness = Math.round(waterScore * 0.35 + sleepScore * 0.40 + restScore * 0.25);

  const updateProfile = (key, value) => setData(d => ({ ...d, profile: { ...d.profile, [key]: value } }));
  const updateSleep = (key, value) => setData(d => ({ ...d, sleep: { ...d.sleep, [key]: value } }));
  const addWater = amount => setData(d => ({ ...d, water: Math.max(0, d.water + amount) }));
  const resetDay = () => {
    setData(d => ({ ...d, logs: { ...d.logs, [todayKey()]: { water: d.water, sleep: hours, restfulness: d.sleep.restfulness } }, water: 0 }));
    setNotice("Today's water log was saved and reset.");
  };
  const saveToday = () => {
    setData(d => ({ ...d, logs: { ...d.logs, [todayKey()]: { water: d.water, sleep: hours, restfulness: d.sleep.restfulness } } }));
    setNotice("Today's wellness log saved.");
  };

  const nav = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "history", label: "7-day history", icon: History },
    { id: "tips", label: "Wellness tips", icon: Lightbulb }
  ];

  return (
    <div className={dark ? "app dark" : "app"}>
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><HeartPulse size={22}/></div>
          <div><strong>BodyBlueprint</strong><span>HEALTHHUB</span></div>
        </div>
        <div className="nav-label">WORKSPACE</div>
        <nav>
          {nav.map(item => {
            const Icon = item.icon;
            return <button key={item.id} className={page === item.id ? "nav-item active" : "nav-item"} onClick={() => setPage(item.id)}>
              <Icon size={18}/><span>{item.label}</span>
            </button>;
          })}
        </nav>
        <div className="sidebar-bottom">
          <div className="privacy-note"><Info size={16}/><span>Your entries are saved locally in this browser.</span></div>
          <button className="nav-item" onClick={() => setDark(v => !v)}>{dark ? <Sun size={18}/> : <MoonStar size={18}/>}<span>{dark ? "Light theme" : "Dark theme"}</span></button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="mobile-brand"><HeartPulse size={20}/> BodyBlueprint</div>
          <div className="breadcrumb">HealthHub <span>/</span> {nav.find(n => n.id === page)?.label}</div>
          <div className="top-actions"><span className="today"><CalendarDays size={15}/> {new Date().toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}</span><div className="avatar">BB</div></div>
        </header>

        {notice && <div className="toast"><CheckCircle2 size={17}/>{notice}</div>}

        {page === "dashboard" && <Dashboard
          data={data} bmi={bmi} bmr={bmr} hours={hours} wellness={wellness}
          waterScore={waterScore} sleepScore={sleepScore} restScore={restScore}
          updateProfile={updateProfile} updateSleep={updateSleep} addWater={addWater}
          saveToday={saveToday} resetDay={resetDay} setNotice={setNotice}
        />}
        {page === "history" && <HistoryPage data={data} hours={hours} />}
        {page === "tips" && <TipsPage water={data.water} hours={hours} />}
        <footer>BodyBlueprint is an educational wellness demo · Not a medical or diagnostic tool</footer>
      </main>
    </div>
  );
}

function Dashboard(props) {
  const { data, bmi, bmr, hours, wellness, waterScore, sleepScore, restScore,
    updateProfile, updateSleep, addWater, saveToday, resetDay, setNotice } = props;
  const age = Number(data.profile.age);
  const recommendations = [];
  if (data.water < 1500) recommendations.push({ title: "Keep water nearby", text: "Your logged water is still below the demo goal. Consider sipping water regularly through the day." });
  if (hours > 0 && hours < 8) recommendations.push({ title: "Make room for rest", text: "Your sleep log is below eight hours. A steady, relaxing bedtime routine may help." });
  if (Number(data.sleep.restfulness) <= 2) recommendations.push({ title: "Check in with your routine", text: "You rated last night's restfulness low. Notice patterns and consider discussing ongoing sleep concerns with a trusted adult or health professional." });
  if (!recommendations.length) recommendations.push({ title: "Keep tracking gently", text: "Your logged habits are moving toward the example targets. Consistency matters more than a single day's number." });

  return <div className="content">
    <section className="welcome">
      <div><div className="eyebrow"><Sparkles size={14}/> YOUR PERSONAL WELLNESS SPACE</div><h1>Good day. <span>Small steps add up.</span></h1><p>Track a few daily habits and explore your wellness patterns.</p></div>
      <div className="welcome-art"><div className="orb orb-one"></div><div className="orb orb-two"></div><Activity size={46}/></div>
    </section>

    <section className="score-row">
      <div className="score-card">
        <div className="score-head"><div><span className="muted-label">DAILY WELLNESS INDICATOR</span><h2>Your daily snapshot</h2></div><div className="score-icon"><HeartPulse size={21}/></div></div>
        <div className="score-main"><div className="score-number">{wellness}<small>/100</small></div><div className="score-copy"><strong>Habit snapshot</strong><span>Based on hydration, sleep duration and restfulness logs.</span></div></div>
        <div className="score-bar"><span style={{ width: `${wellness}%` }}></span></div>
        <div className="score-foot"><span>Hydration 35%</span><span>Sleep duration 40%</span><span>Restfulness 25%</span></div>
      </div>
      <div className="mini-card">
        <div className="mini-icon purple"><Moon size={19}/></div><span className="muted-label">SLEEP LOG</span><strong>{hours.toFixed(1)} <small>hrs</small></strong><span className="mini-sub">Restfulness: {data.sleep.restfulness}/5</span>
      </div>
      <div className="mini-card">
        <div className="mini-icon blue"><Droplets size={19}/></div><span className="muted-label">WATER LOG</span><strong>{(data.water / 1000).toFixed(2)} <small>L</small></strong><span className="mini-sub">Example goal: 2.0 L</span>
      </div>
    </section>

    <div className="section-title"><div><h2>Your trackers</h2><p>Update your daily entries below.</p></div><button className="btn btn-soft" onClick={saveToday}><CheckCircle2 size={16}/> Save today's log</button></div>
    <section className="tracker-grid">
      <div className="panel">
        <div className="panel-title"><div className="panel-icon blue"><Droplets size={19}/></div><div><h3>Hydration tracker</h3><p>Record water as you drink it</p></div></div>
        <div className="water-total"><strong>{data.water.toLocaleString()}<small> ml</small></strong><span>of {hydrationGoalLabel} ml example goal</span></div>
        <div className="water-track"><div style={{ width: `${Math.min(100, data.water / 2000 * 100)}%` }}></div></div>
        <div className="progress-label"><span>{Math.round(Math.min(100, data.water / 2000 * 100))}% logged</span><span>{Math.max(0, 2000 - data.water).toLocaleString()} ml to example goal</span></div>
        <div className="water-actions"><button className="btn btn-primary" onClick={() => addWater(250)}><Plus size={16}/> 250 ml</button><button className="btn btn-outline" onClick={() => addWater(500)}><Plus size={16}/> 500 ml</button><button className="icon-btn" title="Reset water log" onClick={resetDay}><RotateCcw size={16}/></button></div>
        <p className="helper"><Info size={14}/> The 2 L value is a demo target, not an individual prescription. Needs vary.</p>
      </div>

      <div className="panel">
        <div className="panel-title"><div className="panel-icon purple"><Moon size={19}/></div><div><h3>Sleep tracker</h3><p>Log your sleep and how rested you feel</p></div></div>
        <div className="sleep-inputs">
          <label>Bedtime<input type="time" value={data.sleep.bedtime} onChange={e => updateSleep("bedtime", e.target.value)}/></label>
          <label>Wake-up time<input type="time" value={data.sleep.wakeTime} onChange={e => updateSleep("wakeTime", e.target.value)}/></label>
        </div>
        <div className="sleep-result"><div className="sleep-clock"><Clock3 size={21}/></div><div><strong>{hours.toFixed(1)} hours</strong><span>Calculated sleep duration</span></div></div>
        <div className="rating-label">How restful did it feel?</div>
        <div className="stars" role="group" aria-label="Restfulness rating">
          {[1,2,3,4,5].map(n => <button key={n} className={n <= data.sleep.restfulness ? "star selected" : "star"} onClick={() => updateSleep("restfulness", n)} aria-label={`${n} stars`}>★</button>)}
          <span>{data.sleep.restfulness}/5</span>
        </div>
        <p className="helper"><Info size={14}/> Sleep needs vary with age and individual circumstances.</p>
      </div>
    </section>

    <section className="lower-grid">
      <div className="panel metrics-panel">
        <div className="panel-title"><div className="panel-icon green"><Activity size={19}/></div><div><h3>Body metrics</h3><p>Optional educational estimates</p></div></div>
        <div className="form-grid">
          <label>Age (years)<input type="number" min="1" max="100" placeholder="e.g. 20" value={data.profile.age} onChange={e => updateProfile("age", e.target.value)}/></label>
          <label>Biological sex<select value={data.profile.sex} onChange={e => updateProfile("sex", e.target.value)}><option value="female">Female</option><option value="male">Male</option></select></label>
          <label>Height (cm)<input type="number" min="1" placeholder="e.g. 170" value={data.profile.height} onChange={e => updateProfile("height", e.target.value)}/></label>
          <label>Weight (kg)<input type="number" min="1" placeholder="e.g. 65" value={data.profile.weight} onChange={e => updateProfile("weight", e.target.value)}/></label>
        </div>
        <div className="metric-results">
          <div><span>BMI estimate</span><strong>{bmi && Number.isFinite(bmi) ? bmi.toFixed(1) : "—"}</strong><small>Not a diagnosis or health grade</small></div>
          <div><span>BMR estimate</span><strong>{bmr ? `${Math.round(bmr)}` : "—"}</strong><small>{bmr ? "kcal/day · adult equation estimate" : "Available only for ages 18+ in this demo"}</small></div>
        </div>
        {age > 0 && age < 18 && <div className="safety-note"><Info size={16}/> For people under 18, adult BMI categories and adult BMR equations are not appropriate. BMI-for-age needs age- and sex-specific growth references and suitable professional context.</div>}
        <div className="helper"><Info size={14}/> BMI is a limited screening measure. The wellness indicator does not score body size or weight.</div>
      </div>

      <div className="panel advice-panel">
        <div className="panel-title"><div className="panel-icon amber"><Lightbulb size={19}/></div><div><h3>Personalized wellness notes</h3><p>Gentle ideas based on today's logs</p></div></div>
        <div className="advice-list">{recommendations.slice(0,3).map((r,i) => <div className="advice-item" key={i}><div className="advice-dot"><ArrowUpRight size={15}/></div><div><strong>{r.title}</strong><p>{r.text}</p></div></div>)}</div>
        <div className="disclaimer"><Info size={15}/> Educational suggestions only. They do not diagnose, treat, or replace professional advice.</div>
      </div>
    </section>
  </div>;
}
const hydrationGoalLabel = "2,000";

function HistoryPage({ data, hours }) {
  const entries = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0,10);
    const log = data.logs[key] || (i === 0 ? { water: data.water, sleep: hours, restfulness: data.sleep.restfulness } : null);
    entries.push({ label: d.toLocaleDateString(undefined,{weekday:"short"}), water: log?.water || 0, sleep: log?.sleep || 0 });
  }
  const maxWater = Math.max(2000, ...entries.map(e => e.water));
  return <div className="content"><div className="page-heading"><div className="eyebrow"><History size={14}/> YOUR PROGRESS</div><h1>7-day history</h1><p>Review the records saved in this browser. Unlogged days appear as zero.</p></div>
    <div className="panel history-panel"><h3>Water intake</h3><p className="panel-desc">Logged millilitres per day</p><div className="bars">{entries.map((e,i)=><div className="bar-col" key={i}><span className="bar-value">{e.water ? `${e.water}` : "—"}</span><div className="bar-bg"><div className="bar-fill" style={{height:`${e.water/maxWater*100}%`}}></div></div><span className="bar-label">{e.label}</span></div>)}</div></div>
    <div className="panel history-panel"><h3>Sleep duration</h3><p className="panel-desc">Hours recorded per day</p><div className="bars">{entries.map((e,i)=><div className="bar-col" key={i}><span className="bar-value">{e.sleep ? `${e.sleep}h` : "—"}</span><div className="bar-bg"><div className="bar-fill purple-fill" style={{height:`${Math.min(100,e.sleep/10*100)}%`}}></div></div><span className="bar-label">{e.label}</span></div>)}</div></div>
  </div>;
}

function TipsPage({ water, hours }) {
  const tips = [
    ["Hydration", "Keep a refillable water bottle accessible. Drink according to thirst, activity, weather, and any guidance from your healthcare professional."],
    ["Sleep routine", "Try a regular wind-down routine. Reduce bright screens before bed if they make it harder for you to settle."],
    ["Daily movement", "Choose enjoyable movement that fits your day, such as walking, cycling, dancing, or a sport you like."],
    ["Balanced meals", "Aim for varied meals and regular nourishment. Avoid extreme food rules or restrictive diets."],
    ["Notice patterns", "A single day does not tell the whole story. Look at trends over time and how you feel."]
  ];
  return <div className="content"><div className="page-heading"><div className="eyebrow"><Lightbulb size={14}/> SMALL, PRACTICAL IDEAS</div><h1>Wellness tips</h1><p>Simple educational ideas to support everyday routines.</p></div>
    <div className="tips-grid">{tips.map(([title,text],i)=><div className="panel tip-card" key={title}><div className={`tip-number n${i+1}`}>0{i+1}</div><h3>{title}</h3><p>{text}</p></div>)}</div>
    <div className="safety-note wide-note"><Info size={17}/> If you have health concerns, specific hydration needs, persistent sleep difficulties, or a medical condition, ask a qualified health professional for advice suited to you.</div>
  </div>;
}

export default App;
